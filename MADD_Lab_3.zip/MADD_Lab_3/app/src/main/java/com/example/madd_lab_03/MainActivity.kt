package com.example.madd_lab_03

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.fragment.app.Fragment

class MainActivity : AppCompatActivity(), MainFragment.OnCalculationListener {
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        
        if (savedInstanceState == null) {
            showMainFragment()
        }
    }
    
    private fun showMainFragment() {
        val mainFragment = MainFragment()
        mainFragment.setOnCalculationListener(this)
        
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragmentContainer, mainFragment)
            .commit()
    }
    
    override fun onCalculation(number1: Double, number2: Double, operation: String) {
        val result = when (operation) {
            "+" -> number1 + number2
            "-" -> number1 - number2
            "×" -> number1 * number2
            "÷" -> if (number2 != 0.0) number1 / number2 else Double.NaN
            else -> 0.0
        }
        
        val answerFragment = AnswerFragment()
        
        // Pass the result as an argument to the fragment
        val args = Bundle()
        args.putDouble("result", result)
        answerFragment.arguments = args
        
        try {
            supportFragmentManager.beginTransaction()
                .replace(R.id.fragmentContainer, answerFragment)
                .addToBackStack(null)
                .commit()
        } catch (e: Exception) {
            // Handle any fragment transaction errors
            e.printStackTrace()
        }
    }
}