package com.example.madd_lab_03

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.fragment.app.Fragment

class AnswerFragment : Fragment() {

    private lateinit var textViewAnswer: TextView
    private lateinit var buttonBack: Button

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_answer, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        
        textViewAnswer = view.findViewById(R.id.textViewAnswer)
        buttonBack = view.findViewById(R.id.buttonBack)

        buttonBack.setOnClickListener {
            parentFragmentManager.popBackStack()
        }
        
        // Get the result from arguments and display it
        arguments?.let { args ->
            val result = args.getDouble("result", 0.0)
            displayAnswer(result)
        }
    }

    private fun displayAnswer(result: Double) {
        textViewAnswer.text = "Answer: $result"
    }
}
