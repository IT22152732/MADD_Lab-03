package com.example.madd_lab_03

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import androidx.fragment.app.Fragment

class MainFragment : Fragment() {

    private lateinit var editTextNumber1: EditText
    private lateinit var editTextNumber2: EditText
    private lateinit var buttonAdd: Button
    private lateinit var buttonSubtract: Button
    private lateinit var buttonMultiply: Button
    private lateinit var buttonDivide: Button

    interface OnCalculationListener {
        fun onCalculation(number1: Double, number2: Double, operation: String)
    }

    private var calculationListener: OnCalculationListener? = null

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_main, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        
        editTextNumber1 = view.findViewById(R.id.editTextNumber1)
        editTextNumber2 = view.findViewById(R.id.editTextNumber2)
        buttonAdd = view.findViewById(R.id.buttonAdd)
        buttonSubtract = view.findViewById(R.id.buttonSubtract)
        buttonMultiply = view.findViewById(R.id.buttonMultiply)
        buttonDivide = view.findViewById(R.id.buttonDivide)

        setupClickListeners()
    }

    private fun setupClickListeners() {
        buttonAdd.setOnClickListener { performCalculation("+") }
        buttonSubtract.setOnClickListener { performCalculation("-") }
        buttonMultiply.setOnClickListener { performCalculation("×") }
        buttonDivide.setOnClickListener { performCalculation("÷") }
    }

    private fun performCalculation(operation: String) {
        val number1Text = editTextNumber1.text.toString().trim()
        val number2Text = editTextNumber2.text.toString().trim()

        if (number1Text.isEmpty() || number2Text.isEmpty()) {
            return
        }

        try {
            val number1 = number1Text.toDouble()
            val number2 = number2Text.toDouble()
            calculationListener?.let { listener ->
                listener.onCalculation(number1, number2, operation)
            }
        } catch (e: NumberFormatException) {
            // Handle invalid input - could show a toast here
            return
        }
    }

    fun setOnCalculationListener(listener: OnCalculationListener) {
        this.calculationListener = listener
    }
}
